public class Course {
    private String name;
    private double baseFee;
    private int discount;
    private int netFee;

    // Constructor
    public Course(String name, double baseFee, int discount, int netFee) {
        this.name = name;
        this.baseFee = baseFee;
        this.discount = discount;
        this.netFee = netFee;
    }

    // Getters
    public String getName() {
        return name;
    }

    public double getBaseFee() {
        return baseFee;
    }

    public int getDiscount() {
        return discount;
    }

    public int getNetFee() {
        return netFee;
    }
}
