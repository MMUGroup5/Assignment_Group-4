import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class FinanceFeesPanel extends JPanel {
    private JTable feesTable;
    private DefaultTableModel tableModel;
    @SuppressWarnings("unused")
    private BillingSystem mainFrame; // Reference to the main frame for navigation
    private StudentActivityPanel activityPanel;

    public FinanceFeesPanel(BillingSystem mainFrame) {
        this.mainFrame = mainFrame;
        this.setLayout(new BorderLayout());
        this.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Initialize the table model with columns
        String[] columnNames = {"Select", "Course Name", "Base Fee (RM)", "Discount (RM)", "Net Fee (RM)"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) {
                    return Boolean.class; // The first column is for checkboxes
                }
                return String.class;
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 0; // Only the checkbox column is editable
            }
        };

        // Create JTable with the initialized table model
        feesTable = new JTable(tableModel);
        feesTable.setFont(new Font("Arial", Font.PLAIN, 14));
        feesTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        feesTable.setRowHeight(30);
        feesTable.setSelectionBackground(new Color(173, 216, 230)); // Light blue for selection
        feesTable.setSelectionForeground(Color.BLACK); // Text color for selected row
        JScrollPane scrollPane = new JScrollPane(feesTable);

        // Create Calculate Total Fee button with a modern look
        JButton calculateButton = new JButton("Calculate Total Fee");
        calculateButton.setFont(new Font("Arial", Font.PLAIN, 16));
        calculateButton.setBackground(new Color(51, 153, 255)); // Cornflower Blue
        calculateButton.setForeground(Color.WHITE);
        calculateButton.setFocusPainted(false);
        calculateButton.setBorderPainted(false);
        calculateButton.setPreferredSize(new Dimension(200, 40));
        calculateButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateTotalFee();
            }
        });

        // Create Exit button with a modern look
        JButton exitButton = new JButton("Back to Admin Panel");
        exitButton.setFont(new Font("Arial", Font.PLAIN, 16));
        exitButton.setBackground(new Color(51, 153, 255)); // Cornflower Blue
        exitButton.setForeground(Color.WHITE);
        exitButton.setFocusPainted(false);
        exitButton.setBorderPainted(false);
        exitButton.setPreferredSize(new Dimension(200, 40));
        exitButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (mainFrame != null) {
                    mainFrame.showPanel("admin"); // Navigate back to the Admin Panel
                } else {
                    System.out.println("Navigation error: mainFrame is null.");
                }
            }
        });

        // Create and add title label
        JLabel titleLabel = new JLabel("Finance Fees Panel", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));

        // Create a spacer panel to add space between the title and the table
        JPanel spacerPanel = new JPanel();
        spacerPanel.setPreferredSize(new Dimension(0, 30)); // Adjust height as needed

        // Add components to the panel
        this.add(titleLabel, BorderLayout.NORTH);
        this.add(spacerPanel, BorderLayout.CENTER); // Add spacer panel
        this.add(scrollPane, BorderLayout.CENTER); // Add the table in the center
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(calculateButton);
        buttonPanel.add(exitButton);
        this.add(buttonPanel, BorderLayout.SOUTH);

        // Initialize the activity panel
        activityPanel = new StudentActivityPanel(mainFrame);

        // Populate table with sample data
        populateSampleData();
    }

    // Method to populate the table with sample data
    private void populateSampleData() {
        List<Course> sampleCourses = new ArrayList<>();
        sampleCourses.add(new Course("Level 1 Matriculation", 1000, 0, 1000));  // Net fee = Base fee - Discount
        sampleCourses.add(new Course("Level 2 Undergraduate", 6000 * 3, 1800, 16200)); // Net fee = Base fee - Discount
        sampleCourses.add(new Course("Level 3 Postgraduate", 3000 * 1.5, 450, 4050));  // Net fee = Base fee - Discount
        sampleCourses.add(new Course("Special Case", 10000 * 5, 15000, 35000));      // Net fee = Base fee - Discount (Negative if discount > base fee)

        updateFeeTable(sampleCourses);
    }

    // Method to update the fee table with course details
    public void updateFeeTable(List<Course> selectedCourses) {
        // Clear existing rows
        tableModel.setRowCount(0);

        // Populate the table with course data
        for (Course course : selectedCourses) {
            Object[] rowData = {
                    false, // Checkbox initially unchecked
                    course.getName(),
                    String.format("RM %.2f", course.getBaseFee()),
                    String.format("RM %d", course.getDiscount()),
                    String.format("RM %d", course.getNetFee())
            };
            tableModel.addRow(rowData);
        }
    }

    // Method to calculate the total fee
    private void calculateTotalFee() {
        int totalCourseFee = 0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            if ((Boolean) tableModel.getValueAt(i, 0)) {
                totalCourseFee += Integer.parseInt(((String) tableModel.getValueAt(i, 4)).replace("RM ", ""));
            }
        }

        int activityFee = activityPanel.getTotalActivityFee();
        int totalFee = totalCourseFee + activityFee;

        System.out.println("Overall Fees: RM" + totalFee);
    }

    // Main method for testing the panel
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Finance Fees Panel Test");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(800, 600); // Adjusted size for larger panel
            frame.getContentPane().add(new FinanceFeesPanel(null)); // Passing null for testing
            frame.setVisible(true);
        });
    }
}
