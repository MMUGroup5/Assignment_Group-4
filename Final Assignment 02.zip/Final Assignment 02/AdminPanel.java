import javax.swing.*;
import java.awt.*;

public class AdminPanel extends JPanel {
    @SuppressWarnings("unused")
    private BillingSystem mainFrame;
    private JButton registerStudentButton;
    private JButton selectCourseButton;
    private JButton studentActivityButton;
    private JButton hostelButton;
    private JButton financeFeesButton;

    public AdminPanel(BillingSystem mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());
        setBackground(new Color(240, 248, 255)); // Light blue background

        // Create and set up header panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(51, 153, 255)); // Darker blue
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding
        JLabel headerLabel = new JLabel("Admin Panel");
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Create and set up button panel with GridBagLayout
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setOpaque(false); // Make sure buttonPanel is transparent
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0; // Allow buttons to expand horizontally

        // Initialize buttons with enhanced styling
        registerStudentButton = createStyledButton("Register Student");
        selectCourseButton = createStyledButton("Select Course");
        studentActivityButton = createStyledButton("Student Activity");
        hostelButton = createStyledButton("Hostel");
        financeFeesButton = createStyledButton("Finance Fees");

        // Add buttons to panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        buttonPanel.add(registerStudentButton, gbc);

        gbc.gridy++;
        buttonPanel.add(selectCourseButton, gbc);

        gbc.gridy++;
        buttonPanel.add(studentActivityButton, gbc);

        gbc.gridy++;
        buttonPanel.add(hostelButton, gbc);

        gbc.gridy++;
        buttonPanel.add(financeFeesButton, gbc);

        // Add button panel to the center of the AdminPanel
        add(buttonPanel, BorderLayout.CENTER);

        // Add action listeners
        registerStudentButton.addActionListener(e -> mainFrame.showPanel("registerStudent"));
        selectCourseButton.addActionListener(e -> mainFrame.showPanel("selectCourse"));
        studentActivityButton.addActionListener(e -> mainFrame.showPanel("studentActivity"));
        hostelButton.addActionListener(e -> mainFrame.showPanel("hostel"));
        financeFeesButton.addActionListener(e -> mainFrame.showPanel("financeFees"));
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        button.setPreferredSize(new Dimension(250, 50));
        button.setBackground(new Color(51, 153, 255)); // Blue color
        button.setForeground(Color.WHITE); // White text
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0, 102, 204), 2), 
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        )); // White border with padding
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Hand cursor on hover

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(0, 122, 204)); // Darker blue on hover
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(51, 153, 255)); // Original blue
            }
        });

        return button;
    }
}
