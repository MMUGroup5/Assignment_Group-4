import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class StudentActivityPanel extends JPanel {
    @SuppressWarnings("unused")
    private BillingSystem mainFrame;
    private JCheckBox accommodationCheckBox;
    private JCheckBox networkFeeCheckBox;
    private JCheckBox libraryFeeCheckBox;
    private JCheckBox clubSocietyFeeCheckBox;
    private JButton calculateButton;
    private JButton backButton;
    private JLabel resultLabel;

    public StudentActivityPanel(BillingSystem mainFrame) {
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());
        setBackground(new Color(240, 248, 255)); // Light blue background

        // Create title panel
        JPanel titlePanel = new JPanel();
        titlePanel.setBackground(new Color(51, 153, 255)); // Darker blue
        JLabel titleLabel = new JLabel("Student Activity and Fees");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titlePanel.add(titleLabel);

        // Create form panel with GridBagLayout
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        formPanel.setOpaque(false); // Ensure formPanel is not opaque
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        // Checkbox for accommodation
        accommodationCheckBox = new JCheckBox("Require Accommodation?");
        accommodationCheckBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        accommodationCheckBox.setOpaque(false);

        // Checkbox for network fee (mandatory)
        networkFeeCheckBox = new JCheckBox("Network Fee (Mandatory)");
        networkFeeCheckBox.setSelected(true); // Default to selected and disabled
        networkFeeCheckBox.setEnabled(false);
        networkFeeCheckBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        networkFeeCheckBox.setOpaque(false);

        // Checkbox for library fee (mandatory)
        libraryFeeCheckBox = new JCheckBox("Library Fee (Mandatory)");
        libraryFeeCheckBox.setSelected(true); // Default to selected and disabled
        libraryFeeCheckBox.setEnabled(false);
        libraryFeeCheckBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        libraryFeeCheckBox.setOpaque(false);

        // Checkbox for club and society fee (mandatory)
        clubSocietyFeeCheckBox = new JCheckBox("Club and Society Fee (Mandatory)");
        clubSocietyFeeCheckBox.setSelected(true); // Default to selected and disabled
        clubSocietyFeeCheckBox.setEnabled(false);
        clubSocietyFeeCheckBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        clubSocietyFeeCheckBox.setOpaque(false);

        // Button to calculate total fee
        calculateButton = createStyledButton("Calculate Total Fee");

        // Button to navigate back to admin panel
        backButton = createStyledButton("Back to Admin Panel");

        // Label to display total fee
        resultLabel = new JLabel("Total Fee: RM0");
        resultLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        resultLabel.setForeground(new Color(51, 153, 255)); // Darker blue

        // Add components to form panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(accommodationCheckBox, gbc);

        gbc.gridy++;
        formPanel.add(networkFeeCheckBox, gbc);

        gbc.gridy++;
        formPanel.add(libraryFeeCheckBox, gbc);

        gbc.gridy++;
        formPanel.add(clubSocietyFeeCheckBox, gbc);

        gbc.gridy++;
        gbc.gridwidth = 2; // Span across columns
        formPanel.add(calculateButton, gbc);

        gbc.gridy++;
        formPanel.add(resultLabel, gbc);

        gbc.gridy++;
        formPanel.add(backButton, gbc);

        // Add panels to main panel
        add(titlePanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);

        // Add action listeners
        calculateButton.addActionListener(e -> calculateTotalActivityFee()); // Call method to calculate activity fees
        backButton.addActionListener(e -> mainFrame.showPanel("admin"));
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        button.setPreferredSize(new Dimension(200, 50));
        button.setBackground(new Color(51, 153, 255)); // Blue color
        button.setForeground(Color.WHITE); // White text
        button.setFocusPainted(false);
        button.setOpaque(true);
        button.setContentAreaFilled(true);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0, 102, 204), 2), 
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        )); // Blue border with padding
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Hand cursor on hover

        button.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(51, 153, 255)); // Darker blue on hover
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(51, 153, 255)); // Original blue
            }
        });

        return button;
    }

    // Method to calculate total activity fees
    public void calculateTotalActivityFee() {
        int networkFee = 100; // Example network fee
        int libraryFee = 50; // Example library fee
        int clubSocietyFee = 75; // Example club and society fee
        int accommodationFee = 200; // Example accommodation fee

        int totalFee = 0;

        // Add mandatory fees
        if (networkFeeCheckBox.isSelected()) {
            totalFee += networkFee;
        }
        if (libraryFeeCheckBox.isSelected()) {
            totalFee += libraryFee;
        }
        if (clubSocietyFeeCheckBox.isSelected()) {
            totalFee += clubSocietyFee;
        }
        
        // Add accommodation fee if applicable
        if (accommodationCheckBox.isSelected()) {
            totalFee += accommodationFee;
        }

        // Update the result label with detailed fee breakdown
        String resultText = "<html>";
        resultText += "Network Fee: RM" + networkFee + "<br>";
        resultText += "Library Fee: RM" + libraryFee + "<br>";
        resultText += "Club and Society Fee: RM" + clubSocietyFee + "<br>";
        if (accommodationCheckBox.isSelected()) {
            resultText += "Accommodation Fee: RM" + accommodationFee + "<br>";
        }
        resultText += "Total Fee: RM" + totalFee + "</html>";

        resultLabel.setText(resultText);
        
        // Print the result to the terminal
        System.out.println("Network Fee: RM" + networkFee);
        System.out.println("Library Fee: RM" + libraryFee);
        System.out.println("Club and Society Fee: RM" + clubSocietyFee);
        if (accommodationCheckBox.isSelected()) {
            System.out.println("Accommodation Fee: RM" + accommodationFee);
        }
        System.out.println("Total Fee: RM" + totalFee);
        saveTotalFeeToFile(totalFee);
    }


    public int getTotalActivityFee() {
        int networkFee = 100; // Example network fee
        int libraryFee = 50; // Example library fee
        int clubSocietyFee = 75; // Example club and society fee
        int accommodationFee = 200; // Example accommodation fee

        int totalFee = 0;

        // Add mandatory fees
        if (networkFeeCheckBox.isSelected()) {
            totalFee += networkFee;
        }
        if (libraryFeeCheckBox.isSelected()) {
            totalFee += libraryFee;
        }
        if (clubSocietyFeeCheckBox.isSelected()) {
            totalFee += clubSocietyFee;
        }
        
        // Add accommodation fee if applicable
        if (accommodationCheckBox.isSelected()) {
            totalFee += accommodationFee;
        }

        return totalFee;
    }
    private void saveTotalFeeToFile(int totalFee) {
        StringBuilder data = new StringBuilder();
        data.append(totalFee); // Append totalFee to the StringBuilder
    
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("student.txt", true))) {
            if (totalFee == 425) {
                data.append(",");
                writer.write(data.toString());
                // writer.newLine();
            } else {
                writer.write(data.toString());
                writer.newLine(); // Add a new line for other values
            }
         //   System.out.println("Data saved successfully: " + data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
