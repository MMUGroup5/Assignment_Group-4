import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.imageio.ImageIO;

public class SelectCoursePanel extends ImagePanel {
    @SuppressWarnings("unused")
    private BillingSystem mainFrame;
    private JCheckBox level1CheckBox;
    private JCheckBox level2CheckBox;
    private JCheckBox level3CheckBox;
    private JCheckBox specialCaseCheckBox;
    private JButton calculateButton;
    private JButton clearButton;
    private JButton backButton;
    private JTable priceTable;
    private JLabel messageLabel;

    public SelectCoursePanel(BillingSystem mainFrame) {
        super(); // Call the constructor of ImagePanel
        this.mainFrame = mainFrame;
        setLayout(new BorderLayout());

        // Load the background image
        try {
            BufferedImage backgroundImage = ImageIO.read(new File("mmu.jpg")); // Replace with your image file path
            setImage(backgroundImage);
        } catch (IOException e) {
            e.printStackTrace();
        }

        JPanel formPanel = new JPanel();
        formPanel.setOpaque(false); // Make the form panel transparent
        formPanel.setLayout(new BoxLayout(formPanel, BoxLayout.Y_AXIS));
        formPanel.setBorder(new EmptyBorder(100, 40, 40, 10)); // Add padding

        // Checkboxes for course levels with bold text
        level1CheckBox = createCheckBox("Level 1 Matriculation (1 Year)");
        level2CheckBox = createCheckBox("Level 2 Undergraduate (3 Years)");
        level3CheckBox = createCheckBox("Level 3 Postgraduate (1.5 Years)");
        specialCaseCheckBox = createCheckBox("Special Case: M + U + P (5 Years)");

        // Price table setup
        String[] columnNames = {"Course Level", "Base Fee (RM)"};
        Object[][] data = {
                {"Level 1 Matriculation", 1000},
                {"Level 2 Undergraduate", 6000},
                {"Level 3 Postgraduate", 3000},
                {"Special Case", 10000}
        };

        DefaultTableModel tableModel = new DefaultTableModel(data, columnNames);
        priceTable = new JTable(tableModel);
        priceTable.setFont(new Font("Arial", Font.PLAIN, 14));
        priceTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        priceTable.setRowHeight(25);
        JScrollPane tableScrollPane = new JScrollPane(priceTable);
        tableScrollPane.setPreferredSize(new Dimension(400, 150));

        // Calculate, Clear, and Back buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setOpaque(false); // Make the button panel transparent
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 0)); // Center align buttons with spacing
        calculateButton = createButton("Calculate");
        clearButton = createButton("Clear");
        backButton = createButton("Back");
        buttonPanel.add(calculateButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(backButton);

        // Message label for feedback
        messageLabel = new JLabel("Select courses to calculate total fee.");
        messageLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        messageLabel.setForeground(Color.WHITE);
        messageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Adding components to formPanel using BoxLayout
        formPanel.add(level1CheckBox);
        formPanel.add(level2CheckBox);
        formPanel.add(level3CheckBox);
        formPanel.add(specialCaseCheckBox);
        formPanel.add(Box.createVerticalStrut(20));
        formPanel.add(tableScrollPane);
        formPanel.add(Box.createVerticalStrut(20));
        formPanel.add(messageLabel);
        formPanel.add(Box.createVerticalStrut(10));
        formPanel.add(buttonPanel);

        add(formPanel, BorderLayout.CENTER);

        // Action listener for Calculate button
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               double totalFee = calculateTotalFee();
                saveCourseSelection(totalFee);
            }
        });

        // Action listener for Clear button
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearSelections();
            }
        });

        // Action listener for Back button
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.showPanel("admin");
            }
        });
    }

    // Method to calculate total fee based on selected checkboxes
    private double calculateTotalFee() {
        double totalFee = 0.0; // Variable to store total fee

        // Reset message label
        messageLabel.setForeground(Color.WHITE);

        // Determine the fee calculation based on selected checkboxes
        if (level1CheckBox.isSelected()) {
            totalFee += 1000; // Base fee for Level 1 Matriculation
            showMessage("Selected: Level 1 Matriculation - no discount, 1 year");
            System.out.println("Selected: Level 1 Matriculation - no discount, 1 year");
        }

        if (level2CheckBox.isSelected()) {
            double baseFee = 6000; // Base fee for Level 2 Undergraduate
            double discountedFee = baseFee * 0.9; // 10% discount for each year
            totalFee += discountedFee * 3; // Total fee for 3 years
            showMessage("Selected: Level 2 Undergraduate - discount 10% per year, 3 years");
            System.out.println("Selected: Level 2 Undergraduate - discount 10% per year, 3 years");
        }

        if (level3CheckBox.isSelected()) {
            double baseFee = 3000; // Base fee for Level 3 Postgraduate
            double discountedFee = baseFee * 0.9; // 10% discount for each year
            totalFee += discountedFee * 1.5; // Total fee for 1.5 years
            showMessage("Selected: Level 3 Postgraduate - discount 10% per year, 1.5 years");
            System.out.println("Selected: Level 3 Postgraduate - discount 10% per year, 1.5 years");
        }

        if (specialCaseCheckBox.isSelected()) {
            totalFee = 35000; // Special case fee of RM 35,000
            showMessage("Selected: Special Case - fixed fee of RM 35,000");
            System.out.println("Selected: Special Case - fixed fee of RM 35,000");
        }

        // Display the total fee
        if (totalFee > 0) {
            JOptionPane.showMessageDialog(this, "<html><b>Total Fee:</b> RM " + String.format("%.2f", totalFee) + "</html>");
            System.out.println("Total Fee: RM " + String.format("%.2f", totalFee));
        } else {
            showMessage("No courses selected.");
            System.out.println("No courses selected.");
        }
        return totalFee;
    }

   
    // Method to create and customize checkboxes with bold text and padding to the left
    private JCheckBox createCheckBox(String text) {
        JCheckBox checkBox = new JCheckBox(text);
        checkBox.setFont(new Font("Segoe UI", Font.BOLD, 18)); // Bold text
        checkBox.setForeground(new Color(255, 255, 255)); // White text color
        checkBox.setOpaque(false); // Make the checkbox background transparent
        checkBox.setBorder(new EmptyBorder(0, 20, 0, 0)); // Add left padding to move the checkbox to the right
        return checkBox;
    }

    // Method to create and customize buttons
    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        button.setBackground(new Color(51, 153, 255)); // Blue background
        button.setForeground(Color.WHITE); // White text color
        button.setFocusPainted(false); // Remove focus border
        button.setPreferredSize(new Dimension(150, 40)); // Button size
        return button;
    }

    // Method to show messages in message label with bold text
    private void showMessage(String message) {
        messageLabel.setText("<html><b>" + message + "</b></html>");
    }

    // Method to clear all checkbox selections
    private void clearSelections() {
        level1CheckBox.setSelected(false);
        level2CheckBox.setSelected(false);
        level3CheckBox.setSelected(false);
        specialCaseCheckBox.setSelected(false);
        showMessage("Selections cleared.");
        System.out.println("Selections cleared.");
    }
    //Method to store data
      private void saveCourseSelection(double totalFee) {
        StringBuilder data = new StringBuilder();
         if (level1CheckBox.isSelected()) {
            data.append("Matriculation,");
        }
    
        if (level2CheckBox.isSelected()) {
            data.append("Undergraduate,");
        }
    
        if (level3CheckBox.isSelected()) {
            data.append("Postgraduate,");
        }
    
        if (specialCaseCheckBox.isSelected()) {
            data.append("SpecialCase,");
        }
        data.append(String.format("%.2f", totalFee)).append(",");
          try (BufferedWriter writer = new BufferedWriter(new FileWriter("student.txt", true))) {
        writer.write(data.toString());
        //writer.newLine();
      //  System.out.println("Data saved successfully: " + data);
    } catch (IOException e) {
        e.printStackTrace();
      
     }
    }

  // Main method for testing the panel
    // public static void main(String[] args) {
    //     SwingUtilities.invokeLater(new Runnable() {
    //         public void run() {
    //             JFrame frame = new JFrame("Select Course Panel Test");
    //             frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    //             frame.setSize(600, 400);
    //             frame.getContentPane().add(new SelectCoursePanel(null)); // Replace null with your MainFrame instance
    //             frame.setVisible(true);
    //         }
    //     });
    // }
}

class ImagePanel extends JPanel {
    private Image image;

    public ImagePanel() {
        super();
        setLayout(new BorderLayout());
    }

    public void setImage(Image image) {
        this.image = image;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (image != null) {
            g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
        }
    }
}