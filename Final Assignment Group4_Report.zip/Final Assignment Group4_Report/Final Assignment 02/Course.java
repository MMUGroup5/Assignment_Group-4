public class Course {
    private String id;
    private String name;
    private String courseName;
    private double courseFee;
    private int netFee;

    // Constructor
    public Course(String id, String name,String courseName, double courseFee, int netFee) {
   //    super(id, name);
        this.id = id;
        this.name = name;
        this.courseName = courseName;
        this.courseFee = courseFee;
        this.netFee = netFee;
    }

    // Getters

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    
    public String getCourseName() {
        return courseName;
    }

    public double getCourseFee() {
        return courseFee;
    }
   public int getNetFee(){
       return netFee;
   }

  public double getDiscount() {
        String courseName=getCourseName();
        double discount = 0.0;
        double baseFee = 0.0;
        switch (courseName) {
            case "Matriculation":
                // No discount
                break;
            case "Undergraduate":
                baseFee = 6000;
                discount = baseFee * 0.1 * 3; // 10% discount for each year
                break;
            case "Postgraduate":
                discount = baseFee * 0.1 * 1.5; // 10% discount for each year
                break;
            case "Special Case":
                discount = baseFee * 0.15 * 5; // Assuming a different discount for special cases
                break;
            default:
                break;
        }
        return discount;
    }

    public double getOverallFee(){
        return courseFee + netFee;
    }
}
// public class Course {
//     private String name;
//     private double baseFee;
//     private int discount;
//     private int netFee;

//     // Constructor
//     public Course(String name, double baseFee, int discount, int netFee) {
//         this.name = name;
//         this.baseFee = baseFee;
//         this.discount = discount;
//         this.netFee = netFee;
//     }

//     // Getters
//     public String getName() {
//         return name;
//     }

//     public double getBaseFee() {
//         return baseFee;
//     }

//     public int getDiscount() {
//         return discount;
//     }

//     public int getNetFee() {
//         return netFee;
//     }
// }

