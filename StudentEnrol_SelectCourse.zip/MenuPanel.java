import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Color;
import java.awt.Font;

public class MenuPanel extends JPanel {

    public MenuPanel(MainFrame mainFrame) {
        setLayout(new GridBagLayout());
        setBackground(new Color(200, 220, 240)); // Light blue background
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new java.awt.Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        Font buttonFont = new Font("Arial", Font.PLAIN, 18);

        JButton enrollmentButton = new JButton("Student Enrollment");
        enrollmentButton.setFont(buttonFont);
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(enrollmentButton, gbc);

        JButton courseButton = new JButton("Select Course");
        courseButton.setFont(buttonFont);
        gbc.gridx = 1;
        gbc.gridy = 0;
        add(courseButton, gbc);

        JButton feeButton = new JButton("Course Fee");
        feeButton.setFont(buttonFont);
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(feeButton, gbc);

        JButton activityButton = new JButton("Student Activity");
        activityButton.setFont(buttonFont);
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(activityButton, gbc);

        JButton hostelButton = new JButton("Hostel");
        hostelButton.setFont(buttonFont);
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(hostelButton, gbc);

        JButton financesButton = new JButton("Finances");
        financesButton.setFont(buttonFont);
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(financesButton, gbc);

        enrollmentButton.addActionListener(e -> mainFrame.showPanel("StudentEnrollmentPanel"));
        courseButton.addActionListener(e -> mainFrame.showPanel("SelectCoursePanel"));
        feeButton.addActionListener(e -> mainFrame.showPanel("CourseFeePanel"));
        activityButton.addActionListener(e -> mainFrame.showPanel("StudentActivityPanel"));
        hostelButton.addActionListener(e -> mainFrame.showPanel("HostelPanel"));
        financesButton.addActionListener(e -> mainFrame.showPanel("FinancesPanel"));
    }
}
