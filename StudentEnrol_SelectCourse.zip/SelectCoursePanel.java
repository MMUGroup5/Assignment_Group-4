import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Color;
import java.awt.Font;

public class SelectCoursePanel extends JPanel {
    private JComboBox<String> levelComboBox;
    private JComboBox<String> courseComboBox;

    public SelectCoursePanel(MainFrame mainFrame) {
        setLayout(new GridBagLayout());
        setBackground(new Color(200, 220, 240)); // Light blue background
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new java.awt.Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("Select Course");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(titleLabel, gbc);

        gbc.gridwidth = 1;

        JLabel levelLabel = new JLabel("Level:");
        levelLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(levelLabel, gbc);

        levelComboBox = new JComboBox<>(new String[]{"Matriculation", "Undergraduate", "Postgraduate"});
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(levelComboBox, gbc);

        JLabel courseLabel = new JLabel("Course:");
        courseLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(courseLabel, gbc);

        courseComboBox = new JComboBox<>(new String[]{"IT", "Business", "Law", "Engineering","IT + Business + Engineering + Law" });
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(courseComboBox, gbc);

        JButton saveButton = new JButton("Save");
        saveButton.setFont(new Font("Arial", Font.PLAIN, 18));
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(saveButton, gbc);

        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.PLAIN, 18));
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(backButton, gbc);

        saveButton.addActionListener(e -> saveCourse());
        backButton.addActionListener(e -> mainFrame.showPanel("MenuPanel"));
    }

    private void saveCourse() {
        String level = (String) levelComboBox.getSelectedItem();
        String course = (String) courseComboBox.getSelectedItem();

        System.out.println("Course Details Saved:");
        System.out.println("Level: " + level);
        System.out.println("Course: " + course);
    }
}
