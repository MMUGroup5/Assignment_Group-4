import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.CardLayout;

public class MainFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel cardPanel;

    public MainFrame() {
        setTitle("MMU Enrollment System");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        AdminPanel adminPanel = new AdminPanel(this);
        RegisterPanel registerPanel = new RegisterPanel(this);
        LoginPanel loginPanel = new LoginPanel(this);
        MenuPanel menuPanel = new MenuPanel(this);

        StudentEnrollmentPanel studentEnrollmentPanel = new StudentEnrollmentPanel(this);
        SelectCoursePanel selectCoursePanel = new SelectCoursePanel(this);
       
        cardPanel.add(adminPanel, "AdminPanel");
        cardPanel.add(registerPanel, "RegisterPanel");
        cardPanel.add(loginPanel, "LoginPanel");
        cardPanel.add(menuPanel, "MenuPanel");

        cardPanel.add(studentEnrollmentPanel, "StudentEnrollmentPanel");
        cardPanel.add(selectCoursePanel, "SelectCoursePanel");
       

        add(cardPanel);
    }

    public void showPanel(String panelName) {
        cardLayout.show(cardPanel, panelName);
    }

    public static void main(String[] args) {
        MainFrame mainFrame = new MainFrame();
        mainFrame.setVisible(true);
    }
}
