public class LoginAndSignUp {
public static void main(String[] args) {

        Login Login = new Login();
       
    }
    
} 
    

