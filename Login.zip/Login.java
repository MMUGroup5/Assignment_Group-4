import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Login extends JFrame {
    private JSplitPane splitPane;
    private JTextField text1;
    private JPasswordField text2;

    public Login() {
        createAndShowGUI();
    }

    private void createAndShowGUI() {
        setTitle("Admin System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 500);

        // Left panel
        JPanel leftPanel = new JPanel();
        leftPanel.setBackground(Color.LIGHT_GRAY);
        leftPanel.setLayout(null);

        JLabel label1 = new JLabel("Admin Main Page");
        label1.setFont(new Font("Serif", Font.BOLD, 20));
        label1.setForeground(Color.BLACK);
        label1.setBounds(50, 50, 200, 30);  // Set position and size
        leftPanel.add(label1);
  
        JLabel label2 = new JLabel();
        label2.setIcon(new ImageIcon("Campus1.png"));
        label2.setBounds(50, 100, 200, 200);  // Adjust size and position as needed
        leftPanel.add(label2);

        // Right panel
        JPanel rightPanel = new JPanel();
        rightPanel.setBackground(Color.WHITE);

        JLabel label3 = new JLabel("Login");
        label3.setFont(new Font("Serif", Font.BOLD, 20));
        label3.setForeground(Color.BLACK);

        JLabel label4 = new JLabel("User ID");
        label4.setFont(new Font("Serif", Font.BOLD, 15));
        label4.setForeground(Color.BLACK);

        text1 = new JTextField(10);
        text1.setFont(new Font("Serif", Font.BOLD, 15));
        text1.setPreferredSize(new Dimension(200, 30));
        text1.setForeground(Color.BLACK);

        JLabel label5 = new JLabel("Password");
        label5.setFont(new Font("Serif", Font.BOLD, 15));
        label5.setForeground(Color.BLACK);

        text2 = new JPasswordField(10);
        text2.setFont(new Font("Serif", Font.BOLD, 15));
        text2.setPreferredSize(new Dimension(200, 30));
        text2.setForeground(Color.BLACK);

        JButton jButton1 = new JButton("Login");
        jButton1.setFont(new Font("Serif", Font.BOLD, 15));
        jButton1.setForeground(Color.BLACK);
        jButton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });

        JButton jButton2 = new JButton("Sign Up");
        jButton2.setFont(new Font("Serif", Font.BOLD, 15));
        jButton2.setForeground(Color.BLACK);
        jButton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                button2ActionPerformed(evt);
            }
        });

        GroupLayout layout = new GroupLayout(rightPanel);
        rightPanel.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(label3)
                .addComponent(label4)
                .addComponent(text1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addComponent(label5)
                .addComponent(text2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jButton1)
                    .addComponent(jButton2))
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addComponent(label3)
                .addComponent(label4)
                .addComponent(text1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addComponent(label5)
                .addComponent(text2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
        );

        // Split pane
        splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        splitPane.setDividerLocation(300);

        // Add split pane to the frame
        add(splitPane);

        setVisible(true);
    }

    private void button2ActionPerformed(ActionEvent evt) {
        SignUp signUpPage = new SignUp();
        signUpPage.setVisible(true);
        signUpPage.pack();
        signUpPage.setLocationRelativeTo(null);
        signUpPage.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.dispose();
    }

    private void loginActionPerformed(ActionEvent evt) {
        if (!validateLoginData()) {
            return;
        }

        String userID = text1.getText();
        String password = new String(text2.getPassword());

        if (isUserExists(userID, password)) {
            JOptionPane.showMessageDialog(this, "Login successful!");
            // Proceed to the next screen or functionality
        } else {
            JOptionPane.showMessageDialog(this, "Invalid User ID or Password", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
//validate login data
    private boolean validateLoginData() {
        String userID = text1.getText();
        if (userID.isEmpty()) {
            JOptionPane.showMessageDialog(this, "User ID is required", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        String password = new String(text2.getPassword());
        if (password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Password is required", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }
//check if user exists
    private boolean isUserExists(String userID, String password) {
        try (BufferedReader reader = new BufferedReader(new FileReader("UserData.csv"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data[1].equals(userID) && data[3].equals(password)) {
                    return true;
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error reading data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return false;
    }

    // public static void main(String args[]) {
    //     SwingUtilities.invokeLater(new Runnable() {
    //         public void run() {
    //             new Login();
    //         }
    //     });
    // }
}
