import java.awt.*;
import java.io.*;
import javax.swing.*;

public class SignUp extends JFrame {
    private JTextField text1;
    private JTextField text2;
    private JTextField text3;
    private JPasswordField text4;

    public SignUp() {
        createAndShowGUI();
    }

    private void createAndShowGUI() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(700, 500);
        setTitle("Sign Up");

        JPanel panel1 = new JPanel();
        panel1.setBackground(Color.WHITE);

        JLabel label1 = new JLabel("Sign Up");
        label1.setFont(new Font("Segoe UI", Font.BOLD, 20));
        label1.setForeground(Color.BLACK);

        JLabel label2 = new JLabel("Full Name");
        label2.setFont(new Font("Segoe UI", Font.BOLD, 15));
        label2.setForeground(Color.BLACK);

        text1 = new JTextField(10);
        text1.setFont(new Font("Segoe UI", Font.BOLD, 15));
        text1.setForeground(Color.BLACK);

        JLabel label3 = new JLabel("UserID");
        label3.setFont(new Font("Segoe UI", Font.BOLD, 15));
        label3.setForeground(Color.BLACK);

        text2 = new JTextField(10);
        text2.setFont(new Font("Segoe UI", Font.BOLD, 15));
        text2.setForeground(Color.BLACK);

        JLabel label4 = new JLabel("Email");
        label4.setFont(new Font("Segoe UI", Font.BOLD, 15));
        label4.setForeground(Color.BLACK);

        text3 = new JTextField(10);
        text3.setFont(new Font("Segoe UI", Font.BOLD, 15));
        text3.setForeground(Color.BLACK);

        JLabel label5 = new JLabel("Password");
        label5.setFont(new Font("Segoe UI", Font.BOLD, 15));
        label5.setForeground(Color.BLACK);

        text4 = new JPasswordField(10);
        text4.setFont(new Font("Segoe UI", Font.BOLD, 15));
        text4.setForeground(Color.BLACK);

        JButton jButton1 = new JButton("Sign Up");
        jButton1.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jButton1.setForeground(Color.BLACK);
        jButton1.addActionListener(e -> saveSignUpData());

        JButton jButton2 = new JButton("Back");
        jButton2.setFont(new Font("Segoe UI", Font.BOLD, 15));
        jButton2.setForeground(Color.BLACK);
        jButton2.addActionListener(e -> {
            dispose();
            new Login();
        });
    

        GroupLayout layout = new GroupLayout(panel1);
        panel1.setLayout(layout);
        layout.setAutoCreateGaps(true);
        layout.setAutoCreateContainerGaps(true);

        layout.setHorizontalGroup(
            layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                .addComponent(label1)
                .addComponent(label2)
                .addComponent(text1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addComponent(label3)
                .addComponent(text2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addComponent(label4)
                .addComponent(text3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addComponent(label5)
                .addComponent(text4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jButton1)
                    .addComponent(jButton2))
        );

        layout.setVerticalGroup(
            layout.createSequentialGroup()
                .addComponent(label1)
                .addComponent(label2)
                .addComponent(text1)
                .addComponent(label3)
                .addComponent(text2)
                .addComponent(label4)
                .addComponent(text3)
                .addComponent(label5)
                .addComponent(text4)
                .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
        );

        add(panel1);
        setVisible(true);
    }
//store data into the file
    private void saveSignUpData() {
        if (!validateSignUpData()) {
            return;
        }

        String id = text2.getText();

        if (isUserExists(id)) {
            JOptionPane.showMessageDialog(this, "User already exists!");
            return;
        }

        String fullName = text1.getText();
        String email = text3.getText();
        String password = new String(text4.getPassword());

        try (FileWriter writer = new FileWriter("UserData.csv", true)) {
            writer.append(fullName)
                  .append(',')
                  .append(id)
                  .append(',')
                  .append(email)
                  .append(',')
                  .append(password)
                  .append('\n');
            JOptionPane.showMessageDialog(this, "Data saved successfully!");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving data: " + ex.getMessage());
        }
    }
//check the data are filled or not
    private boolean validateSignUpData() {
        String fullName = text1.getText();
        String id = text2.getText();
        String email = text3.getText();
        String password = new String(text4.getPassword());

        if (fullName.isEmpty() || id.isEmpty() || email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill all the fields!");
            return false;
        }
        return true;
    }
//check the user is already exists or not
    private boolean isUserExists(String id) {
        try (BufferedReader reader = new BufferedReader(new FileReader("UserData.csv"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                if (data[1].equals(id)) {
                    return true;
                }
            }
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error reading data: " + ex.getMessage());
        }
        return false;
    }

   
}
